
#ifndef ENEMY_H
#define ENEMY_H
#include <cmath>
class Enemy
{
public:
Enemy();
~Enemy();
int k=1;
int hp;
int att;
int armor;
int attack();
bool isAlive();
void get_damage(int att);
};

#endif // ENEMY_H
