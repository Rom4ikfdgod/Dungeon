#include "generator.h"

Generator::Generator()
{

}
