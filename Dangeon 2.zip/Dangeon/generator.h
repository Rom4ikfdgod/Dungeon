#ifndef GENERATOR_H
#define GENERATOR_H


class Generator
{
public:
    Generator();
};

#endif // GENERATOR_H