#include "player.h"

Player::Player():Enemy()
{
armor=1+k/2;
att=10+k*2;
hp=100+k*5;
}


bool Player::defensed()
{
if (defense)
this->defense=false;
else
this->defense=true;
}

void Player::get_treasure()
{
this->att+=1;
this->hp+=10;
}
