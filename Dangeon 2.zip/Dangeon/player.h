#ifndef PLAYER_H
#define PLAYER_H
#include <QKeyEvent>
#include "enemy.h"
class Player : public Enemy
{
public:
    Player();
    ~Player();
    int x,y,score;
    bool defense=false;
    bool defensed();
    void get_treasure();
};

#endif // PLAYER_H
